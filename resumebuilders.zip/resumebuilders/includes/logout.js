import { initializeApp} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import {getAuth , signOut,onAuthStateChanged} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import {firebaseConfig} from './firebaseconf.js';
// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

let logout = document.querySelector('#logout');


 const Logoutclass = async() =>{
                     await signOut(auth);
                     console.log('logout success');
                     window.location.href='../login.html';
             }
      

logout.addEventListener('click',function(){

        Logoutclass();
})
// check if user logged in or not
// onAuthStateChanged(auth,(user)=>{
//         console.log(user.email);
//         })