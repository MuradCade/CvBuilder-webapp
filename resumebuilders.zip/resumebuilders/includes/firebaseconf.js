 // Import the functions you need from the SDKs you need

  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";

  // TODO: Add SDKs for Firebase products that you want to use

  // https://firebase.google.com/docs/web/setup#available-libraries


  // Your web app's Firebase configuration

  const firebaseConfig = {

    apiKey: "AIzaSyAaBh63gVZRYiHG3X81XXHUa66jvQjX3r4",

    authDomain: "resumebuilder-6452d.firebaseapp.com",

    projectId: "resumebuilder-6452d",

    storageBucket: "resumebuilder-6452d.appspot.com",

    messagingSenderId: "931605523225",

    appId: "1:931605523225:web:137c99aa5552554b2d3388"

  };


  // Initialize Firebase

export {firebaseConfig}
