import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import {getAuth , GoogleAuthProvider,signInWithPopup,
    createUserWithEmailAndPassword,} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
    import {getFirestore,addDoc,collection,getDocs} from"https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
    import {firebaseConfig} from './firebaseconf.js';
    // Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
// call the  get database method
const db = getFirestore();
// initialize google  provider
const provider = new GoogleAuthProvider();


let fullname =document.querySelector('#fullname');
let email=document.querySelector('#email');
let pwd =document.querySelector('#pwd');
let loginbtn = document.querySelector('#loginbtn');
// msg display error message
let msg = document.querySelector('#msg');


loginbtn.addEventListener('click',e=>{
        e.preventDefault();
        
        if(fullname.value == ''){
            msg.style.display='block';
            msg.innerHTML = 'Empty Fullname Field';
        }else if(email.value == ''){
            msg.innerHTML = 'Empty Email Field';
            msg.style.display='block';

        }else if(!validateEmail(email.value)){
            msg.innerHTML = 'Sorry email is not valid';
            msg.style.display='block';
        }
        else if(pwd.value == ''){
            msg.innerHTML = 'Empty Password Field';
            msg.style.display='block';

        }else{
            msg.style.display='none';
            // store data to auth
            createnewuser()
            // store data to userdata

        }
      
        
});

//step1 create user with email and password function
const createnewuser = async() =>{
    const createdemail = email.value;
    const createdpwd = pwd.value;

    createUserWithEmailAndPassword(auth,createdemail,createdpwd).then((usercredential)=>{
      // getting the current user that logged in email
        const user =  usercredential.user.uid;
        // console.log(user);
        storecreateduserintodb(user);
        
   
    }).catch((error) =>{
     //    const errorcode = error.code;
        const errormessage = error.message;
        msg.style.display = 'block';
        msg.innerHTML = error;
       
     
      
     

    });

}

//step2 store created user into userdata database in firestore
    async function storecreateduserintodb(uid){
             // get the current date
  let c = new Date();
  let created_date = c.toLocaleDateString();
        var ref = collection(db,'usersdata');
        const docRef = await addDoc(
                ref,{
                    uid:uid,
                    fullname:fullname.value,
                    email:email.value,
                    date:created_date,
                    role:'customer',
                }
            
        ).then(()=>{
          console.log('user stored in userdata db');
          window.location.href='../dashboard';
        }).catch((error)=>{
            console.log(error.message);

        });
    }
// validate email function
function validateEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  }



  let googleauthbtn = document.querySelector('#googleauth');
//   login with google
const googlesign = async()=>{
    signInWithPopup(auth,provider)
    .then((result)=>{
       const user= result.user;
    //    console.log(user.uid);
    //    console.log(user.displayName);
    //    console.log(user.email);
       storedataongoogleauth(user.uid,user.displayName,user.email);
        // console.log('Access Token : '+user.accessToken);
        // console.log(user);
        
    }).catch((error)=>{
        console.log(error);
    })
}
//this function stores data when user create account using google
    async function storedataongoogleauth(uid,name,useremail){
             // get the current date
  let c = new Date();
  let created_date = c.toLocaleDateString();
        var ref = collection(db,'usersdata');
        const docRef = await addDoc(
                ref,{
                    uid:uid,
                    fullname:name,
                    email:useremail,
                    date:created_date,
                    role:'customer',
                }
            
        ).then(()=>{
          console.log('user stored in userdata db');
          window.location.href='../dashboard';
        }).catch((error)=>{
            console.log(error);

        });
    }
    
googleauthbtn.addEventListener('click',function(){
    googlesign();
})



  