import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import {getAuth , GoogleAuthProvider,signInWithPopup,
    createUserWithEmailAndPassword,signInWithEmailAndPassword} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
    import {getFirestore,addDoc,collection,getDocs,where,query,limit} from"https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
    import {firebaseConfig} from './firebaseconf.js';
    // Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
// call the  get database method
const db = getFirestore();
// initialize google  provider
const provider = new GoogleAuthProvider();



let email = document.querySelector('#email');
let pwd = document.querySelector('#pwd');
let loginbtn = document.querySelector('#loginbtn');
let googlebtn = document.querySelector('#googlebtn');
let msg = document.querySelector('#msg');
// chek username and password from the input


loginbtn.addEventListener('click',e=>{
    e.preventDefault();
    if(email.value == ''){
        msg.innerHTML ='Email Field is empty';
        msg.style.display = 'block';
    }else if(pwd.value ==''){
        msg.innerHTML ='Password Field is empty';
        msg.style.display = 'block';
    }else{
       
        msg.style.display = 'none';
        loginfunction();
    }


})

const loginfunction = async()=>{
    const loginemail = email.value;
    const loginpwd = pwd.value;
    signInWithEmailAndPassword(auth,loginemail,loginpwd).then((usercredential)=>{
         // getting the current user that logged in email
        //    const user = usercredential.user;
         //   this function check user role to decide wheather to let the user in or not (admin,company are only allowed)
        // Checkuserrole(user.email)
        // window.location.
        // console.log('welcome to dashboard');
        window.location.href='../dashboard';
      
       }).catch((error) =>{
        //    const errorcode = error.code;
         msg.style.display = 'block';
         msg.innerHTML = error;
         console.log('login failed'+error);
          
       });

}


// google login
//   login with google
const googlesign = async()=>{
    signInWithPopup(auth,provider)
    .then((result)=>{
       const user= result.user;
    //    checkifuserexistornot(user.email,user.displayName,user.uid,);
    //    console.log(user.uid);
    //    console.log(user.displayName);
    //    console.log(user.email);
    //    storedataongoogleauth(user.uid,user.displayName,user.email);
        // console.log('Access Token : '+user.accessToken);
        // console.log(user);
        storecreateduserintodb(user.uid,user.displayName,user.email);
        
        
    }).catch((error)=>{
         msg.style.display = 'block';
         msg.innerHTML = error;
        console.log(error);
    })
}

// search the email of google account and check
// if the user exist or not
 // check logged user role then redirect it with the suitable dashboard
  // check logged user role then redirect it with the suitable dashboard
   async function checkuserexistongogleauth(useremail) {
      
     
            const docRef = query(collection(db, "usersdata") , where("email", "==", useremail));
            const docSnap = await getDocs(docRef);
            docSnap.forEach((doc) => {
                console.log(doc.data().fullname);
    
            })
        }

 // store google auth data into db
 async function storecreateduserintodb(uid,username,useremail){
    // get the current date
let c = new Date();
let created_date = c.toLocaleDateString();
var ref = collection(db,'usersdata');
const docRef = await addDoc(
       ref,{
           uid:uid,
           fullname:username,
           email:useremail,
           date:created_date,
           role:'customer',
       }
   
).then(()=>{
 console.log('user stored in userdata db');
 window.location.href='../dashboard';
}).catch((error)=>{
   console.log(error.message);

});
}

googlebtn.addEventListener('click',function(){
    googlesign();
});





